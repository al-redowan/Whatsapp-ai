# WhatsApp Monitor - Local Installation Guide

## Complete A-Z Setup Instructions

### System Requirements
- **Operating System**: Windows 10/11, macOS, or Linux
- **Node.js**: Version 16.0.0 or higher
- **RAM**: Minimum 4GB (8GB recommended)
- **Storage**: 1GB free space
- **Internet**: Stable connection required

### Step 1: Install Node.js
1. **Download Node.js**: Visit https://nodejs.org/
2. **Choose Version**: Download the LTS (Long Term Support) version
3. **Install**: Run the installer and follow the setup wizard
4. **Verify Installation**: Open terminal/command prompt and run:
   ```bash
   node --version
   npm --version
   ```

### Step 2: Download and Extract Project
1. **Download**: Extract the provided ZIP file to your desired location
2. **Navigate**: Open terminal/command prompt in the project folder
3. **Verify Files**: Ensure these files are present:
   - `whatsapp-real.js`
   - `file-storage.js`
   - `package-local.json`
   - `public/index.html`

### Step 3: Install Dependencies
1. **Rename Package File**:
   - Rename `package-local.json` to `package.json`
2. **Install Packages**:
   ```bash
   npm install
   ```
3. **Wait for Installation**: This may take 2-5 minutes

### Step 4: Start the Application
1. **Run the Server**:
   ```bash
   npm start
   ```
2. **Wait for Startup**: Look for these messages:
   ```
   ✅ Keep-alive server running on port 3000
   🌐 Monitoring server running on http://0.0.0.0:5000
   📱 QR Code received, scan with your phone
   ```

### Step 5: Access the Dashboard
1. **Open Browser**: Navigate to `http://localhost:5000`
2. **View Dashboard**: You should see the WhatsApp Monitor interface

### Step 6: Connect WhatsApp
1. **Scan QR Code**: 
   - QR code appears in terminal automatically
   - Or click "QR Scan" button on dashboard
2. **Use WhatsApp Mobile App**:
   - Open WhatsApp on your phone
   - Go to Settings → Linked Devices
   - Tap "Link a Device"
   - Scan the QR code displayed
3. **Wait for Connection**: Dashboard will show "Connected" status

### Step 7: Monitor Messages
- **Real-time Tracking**: Messages appear automatically on dashboard
- **Search Function**: Use search box to filter messages
- **Message Limits**: Choose how many messages to display (20/50/100/All)
- **Auto-refresh**: Dashboard updates every 30 seconds

### Troubleshooting

#### Issue: "Command not found: node"
**Solution**: Node.js not installed properly
- Reinstall Node.js from nodejs.org
- Restart terminal after installation

#### Issue: "npm install" fails
**Solution**: Permission or network issues
- Try: `npm install --force`
- Or delete `node_modules` folder and run `npm install` again

#### Issue: Chrome/Browser not found error
**Solution**: Install Google Chrome browser
- Download from: https://www.google.com/chrome/
- Restart application after Chrome installation
- Application will auto-detect Chrome location

#### Issue: Port already in use
**Solution**: Another application using port 5000
- Stop other applications using port 5000
- Or modify port in `whatsapp-real.js` line with `app.listen(5000)`

#### Issue: QR code not appearing
**Solution**: 
- Wait 30-60 seconds for initialization
- Restart the application: `Ctrl+C` then `npm start`
- Check terminal for QR code display

#### Issue: WhatsApp connection fails
**Solution**:
- Ensure stable internet connection
- Try refreshing QR code (click "Refresh QR Code")
- Clear browser cache and restart

#### Issue: Messages not appearing
**Solution**:
- Verify WhatsApp connection status
- Check if groups have new messages
- Click "Refresh" button on dashboard

### Advanced Configuration

#### Change Server Port
Edit `whatsapp-real.js`, find this line:
```javascript
app.listen(5000, '0.0.0.0', () => {
```
Change `5000` to your desired port number.

#### Data Storage Location
Messages are stored in `./data/messages.json`
- View raw message data in this file
- Backup this file to preserve message history

#### Performance Optimization
- **Close unused applications** to free RAM
- **Disable antivirus real-time scanning** for project folder (temporarily)
- **Use wired internet connection** for stability

### Security Notes
- **Local Access Only**: Dashboard accessible only from your computer
- **No External Connections**: Data stays on your local machine
- **WhatsApp Session**: Stored securely in `whatsapp-session` folder

### Updating the Application
1. **Stop Application**: Press `Ctrl+C` in terminal
2. **Update Dependencies**: Run `npm update`
3. **Restart**: Run `npm start`

### Uninstalling
1. **Stop Application**: Press `Ctrl+C`
2. **Delete Folder**: Remove entire project folder
3. **Clean Up**: WhatsApp linked device will automatically disconnect

### Support
- **Log Files**: Check terminal output for error messages
- **Data Backup**: Copy `data` folder to backup messages
- **Fresh Start**: Delete `whatsapp-session` folder to reset connection

### System Resource Usage
- **CPU**: Low usage during normal operation
- **RAM**: ~200-500MB depending on message count
- **Network**: Minimal bandwidth usage
- **Storage**: ~50MB + message data

## Quick Start Commands
```bash
# Navigate to project folder
cd whatsapp-monitor

# Install dependencies
npm install

# Start application
npm start

# Open dashboard
# Visit: http://localhost:5000
```

## File Structure
```
whatsapp-monitor/
├── whatsapp-real.js          # Main application file
├── file-storage.js           # Data management
├── package.json              # Dependencies
├── public/
│   └── index.html           # Dashboard interface
├── data/                    # Message storage (auto-created)
│   ├── messages.json
│   ├── config.json
│   └── groups.json
└── whatsapp-session/        # WhatsApp auth (auto-created)
```

Your WhatsApp monitor is now ready for local deployment!