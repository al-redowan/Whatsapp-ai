#!/bin/bash

echo "WhatsApp Monitor - Linux/Mac Setup Script"
echo "=========================================="
echo ""

# Check if Node.js is installed
echo "Step 1: Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed!"
    echo "Please install Node.js from: https://nodejs.org/"
    echo "After installation, restart this script."
    exit 1
fi

echo "✓ Node.js is installed"
node --version

echo ""
echo "Step 2: Installing dependencies..."

# Prepare package file
if [ -f "package-local.json" ]; then
    cp package-local.json package.json
    echo "✓ Package file prepared"
fi

# Install dependencies
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    echo "Try running: npm install --force"
    exit 1
fi

echo "✓ Dependencies installed successfully"

echo ""
echo "Step 3: Creating data directories..."
mkdir -p data
echo "✓ Data directory ready"

echo ""
echo "Step 4: Starting WhatsApp Monitor..."
echo ""
echo "The dashboard will be available at: http://localhost:5000"
echo ""
echo "Instructions:"
echo "1. Wait for QR code to appear in this terminal"
echo "2. Open WhatsApp on your phone"
echo "3. Go to Settings → Linked Devices → Link a Device"
echo "4. Scan the QR code displayed below"
echo "5. Open your browser to http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Make script executable and start application
chmod +x "$0"
node whatsapp-real.js