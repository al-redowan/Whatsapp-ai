# Windows Chrome Fix Guide

## Issue: Chrome Browser Not Found

If you see this error when running the WhatsApp monitor:
```
Failed to launch the browser process! spawn ENOENT
```

## Solution Steps

### Step 1: Install Google Chrome
1. **Download Chrome**: Visit https://www.google.com/chrome/
2. **Install**: Run the installer with default settings
3. **Verify Installation**: Chrome should be in `C:\Program Files\Google\Chrome\Application\chrome.exe`

### Step 2: Restart Application
1. **Stop Current Process**: Press `Ctrl+C` in terminal
2. **Restart**: Run `node whatsapp-real.js` again
3. **Check Output**: Look for "Found Chrome at:" message

### Step 3: Alternative Chrome Locations
If Chrome is installed but not detected, check these locations:
- `C:\Program Files\Google\Chrome\Application\chrome.exe`
- `C:\Program Files (x86)\Google\Chrome\Application\chrome.exe`
- `%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe`

### Step 4: Manual Chrome Path (Advanced)
If auto-detection fails, edit `whatsapp-real.js`:

1. **Find line ~100** with `puppeteerConfig.executablePath`
2. **Replace with your Chrome path**:
```javascript
puppeteerConfig.executablePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
```

### Expected Success Output
When working correctly, you should see:
```
🔍 Found Chrome at: C:\Program Files\Google\Chrome\Application\chrome.exe
📱 QR Code received, scan with your phone
```

## Alternative Browsers
If Chrome won't work, try installing:
- **Chromium**: Download from https://www.chromium.org/
- **Microsoft Edge**: Usually pre-installed on Windows

## Quick Test
After Chrome installation:
1. Run: `node whatsapp-real.js`
2. Wait for QR code display
3. Open http://localhost:5000 in browser
4. Success: Dashboard loads and shows connection status